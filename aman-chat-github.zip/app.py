
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime

app = Flask(__name__)
socketio = SocketIO(app)

users = {}

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('join')
def handle_join(data):
    username = data['username']
    users[request.sid] = username
    emit('user_joined', {'username': username}, broadcast=True)
    emit('update_users', {'users': list(users.values())}, broadcast=True)

@socketio.on('message')
def handle_message(data):
    now = datetime.now().strftime('%H:%M')
    emit('message', {'username': users[request.sid], 'message': data['message'], 'time': now}, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    username = users.get(request.sid, "مستخدم غير معروف")
    users.pop(request.sid, None)
    emit('user_left', {'username': username}, broadcast=True)
    emit('update_users', {'users': list(users.values())}, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
